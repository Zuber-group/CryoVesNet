from .prepyto import main
main()