import prepyto.main
prepyto.main()